using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate_controller : MonoBehaviour
{
    public Vector3 rotatevector;
 
        void Update()
    {
        transform.Rotate(rotatevector * Time.deltaTime);
        
    }
}
